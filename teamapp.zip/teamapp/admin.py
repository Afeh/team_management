from django.contrib import admin
from .models import TeamMember

admin.site.register(TeamMember)#Register TeamMember Model


